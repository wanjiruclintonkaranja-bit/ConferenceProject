<?php
/* ==========================================================
   process.php
   Receives the registration, validates it on the server,
   calculates the fee independently and shows a confirmation.
   ========================================================== */

// Only accept form submissions (POST)
if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    header("Location: register.html");
    exit;
}

/* ---------- Fee settings (KSh). Must match script.js ---------- */
const REGISTRATION_FEE = 1000;
const FEE_PER_DAY = 500;
const LUNCH_PER_DAY = 300;
const WORKSHOP_FEE = 750;
const MIN_DAYS = 1;
const MAX_DAYS = 3;

// Individual requirement (last digit 3): final-year students get 5% off
const FINAL_YEAR_DISCOUNT_PERCENT = 5;

$workshopNames = [
    "web"   => "Web Development",
    "cyber" => "Cybersecurity Basics",
    "data"  => "Data Analytics",
];

$categoryNames = [
    "conference_only" => "Conference Only",
    "workshop"        => "Workshop Participant",
];

$mealNames = [
    "standard"   => "Standard lunch",
    "vegetarian" => "Vegetarian lunch",
    "halal"      => "Halal lunch",
];

/* ---------- 1. Receive the values ---------- */
$fullName    = trim($_POST["full_name"] ?? "");
$admission   = trim($_POST["admission_number"] ?? "");
$email       = trim($_POST["email"] ?? "");
$phone       = trim($_POST["phone"] ?? "");
$year        = $_POST["year_of_study"] ?? "";
$category    = $_POST["category"] ?? "";
$daysRaw     = $_POST["days"] ?? "";
$wantsMeals  = isset($_POST["catering"]) && $_POST["catering"] === "yes";
$mealOption  = $_POST["meal_option"] ?? "";
$workshop    = $_POST["workshop"] ?? "";
$totalFromJs = $_POST["total_js"] ?? "";

/* ---------- 2 and 3. Check essentials and validate ---------- */
$errors = [];

if ($fullName === "") {
    $errors[] = "Full name is required.";
}

if ($admission === "") {
    $errors[] = "Admission number is required.";
} elseif (!preg_match('/^[A-Za-z0-9\/\-_ ]{3,30}$/', $admission)) {
    $errors[] = "Admission number contains invalid characters.";
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    $errors[] = "Enter a valid email address.";
}

if (!preg_match('/^\d{10}$/', $phone)) {
    $errors[] = "Phone number must be exactly 10 digits.";
}

if (!in_array($year, ["1", "2", "3", "4", "final"], true)) {
    $errors[] = "Select a valid year of study.";
}

if (!array_key_exists($category, $categoryNames)) {
    $errors[] = "Select a valid participation category.";
}

$days = filter_var($daysRaw, FILTER_VALIDATE_INT, [
    "options" => ["min_range" => MIN_DAYS, "max_range" => MAX_DAYS],
]);
if ($days === false) {
    $errors[] = "Number of days must be a whole number from " . MIN_DAYS . " to " . MAX_DAYS . ".";
}

// A workshop only counts for Workshop Participant, and must be a known workshop
$chosenWorkshop = "";
if ($category === "workshop") {
    if (is_string($workshop) && isset($workshopNames[$workshop])) {
        $chosenWorkshop = $workshop;
    } else {
        $errors[] = "Workshop Participants must select a workshop.";
    }
}

if ($wantsMeals && !array_key_exists($mealOption, $mealNames)) {
    $errors[] = "Select a valid meal option.";
}

/* ---------- 4. Calculate the total on the server ---------- */
$subtotal = 0;
$workshopFee = 0;
$attendanceFee = 0;
$mealFee = 0;
$discount = 0;
$totalFee = 0;
$isFinalYear = ($year === "final");

if (count($errors) === 0) {
    $attendanceFee = $days * FEE_PER_DAY;

    if ($chosenWorkshop !== "") {
        $workshopFee = WORKSHOP_FEE;
    }

    if ($wantsMeals) {
        $mealFee = $days * LUNCH_PER_DAY;
    }

    $subtotal = REGISTRATION_FEE + $attendanceFee + $workshopFee + $mealFee;

    // Final-year discount: 5% of the subtotal, rounded to the nearest shilling
    if ($isFinalYear) {
        $discount = (int) round($subtotal * FINAL_YEAR_DISCOUNT_PERCENT / 100);
    }

    $totalFee = $subtotal - $discount;
}

// Compare with the figure JavaScript sent (never trusted, only compared)
$totalMismatch = (count($errors) === 0 && (string) $totalFromJs !== (string) $totalFee);

// Escape text before printing it
function e($text)
{
    return htmlspecialchars((string) $text, ENT_QUOTES, "UTF-8");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Registration | Student Technology and Innovation Conference</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<header class="site-header">
    <nav class="nav-bar" aria-label="Main navigation">
        <a class="brand" href="index.html">STIC 2026</a>
        <ul class="nav-links">
            <li><a href="index.html">Home</a></li>
            <li><a href="index.html#about">About</a></li>
            <li><a href="index.html#fees">Fees</a></li>
            <li><a class="active" href="register.html">Register</a></li>
        </ul>
    </nav>
</header>

<main class="confirm-wrap">
<?php if (count($errors) > 0): ?>

    <div class="receipt">
        <div class="receipt-head fail">
            <h1>REGISTRATION NOT COMPLETED</h1>
        </div>
        <div class="receipt-body">
            <p>Please fix the following and try again:</p>
            <ul class="error-list">
                <?php foreach ($errors as $message): ?>
                    <li><?php echo e($message); ?></li>
                <?php endforeach; ?>
            </ul>
            <a class="btn btn-primary" href="register.html">Back to the form</a>
        </div>
    </div>

<?php else: ?>

    <!-- Page behind the modal -->
    <div class="receipt">
        <div class="receipt-head">
            <h1>Registration received</h1>
        </div>
        <div class="receipt-body">
            <p>Thank you, <?php echo e($fullName); ?>. Your confirmation is shown in the pop-up window.</p>
            <div class="form-actions">
                <button type="button" class="btn btn-primary" id="openConfirmation">View confirmation</button>
                <a class="btn btn-outline" href="index.html">Back to home</a>
            </div>
        </div>
    </div>

    <!-- Confirmation modal. The "open" attribute lets it show even if JavaScript is off;
         js/modal.js removes it and opens the dialog properly. -->
    <dialog class="modal" id="confirmationModal" aria-labelledby="modalTitle" open>
        <div class="receipt">
            <div class="receipt-head modal-head">
                <h1 id="modalTitle">REGISTRATION SUCCESSFUL</h1>
                <button type="button" class="modal-close" id="closeConfirmation" aria-label="Close confirmation">&times;</button>
            </div>
            <div class="receipt-body">

                <?php if ($totalMismatch): ?>
                    <p class="notice">
                        The fee shown on the form did not match our records, so it was
                        recalculated by the server. The amount below is the correct one.
                    </p>
                <?php endif; ?>

                <dl>
                    <dt>Participant</dt>
                    <dd><?php echo e($fullName); ?></dd>

                    <dt>Admission Number</dt>
                    <dd><?php echo e($admission); ?></dd>

                    <dt>Email</dt>
                    <dd><?php echo e($email); ?></dd>

                    <dt>Phone</dt>
                    <dd><?php echo e($phone); ?></dd>

                    <dt>Year of Study</dt>
                    <dd><?php echo $isFinalYear ? "Final year" : "Year " . e($year); ?></dd>

                    <dt>Category</dt>
                    <dd><?php echo e($categoryNames[$category]); ?></dd>

                    <dt>Conference Days</dt>
                    <dd><?php echo e($days); ?></dd>

                    <dt>Workshop</dt>
                    <dd><?php echo $chosenWorkshop === "" ? "None" : e($workshopNames[$chosenWorkshop]); ?></dd>

                    <dt>Meals</dt>
                    <dd><?php echo $wantsMeals ? "Yes (" . e($mealNames[$mealOption]) . ")" : "No"; ?></dd>
                </dl>

                <dl>
                    <dt>Registration fee</dt>
                    <dd>KSh <?php echo number_format(REGISTRATION_FEE); ?></dd>

                    <dt>Attendance fee</dt>
                    <dd>KSh <?php echo number_format($attendanceFee); ?></dd>

                    <dt>Workshop fee</dt>
                    <dd>KSh <?php echo number_format($workshopFee); ?></dd>

                    <dt>Meal fee</dt>
                    <dd>KSh <?php echo number_format($mealFee); ?></dd>

                    <?php if ($discount > 0): ?>
                        <dt>Final-year discount (<?php echo FINAL_YEAR_DISCOUNT_PERCENT; ?>%)</dt>
                        <dd>- KSh <?php echo number_format($discount); ?></dd>
                    <?php endif; ?>
                </dl>
            </div>

            <div class="receipt-total">
                <span>TOTAL AMOUNT PAYABLE</span>
                <span>KSh <?php echo number_format($totalFee); ?></span>
            </div>

            <div class="receipt-body">
                <p>Thank you for registering for the<br>Student Technology and Innovation Conference.</p>
                <div class="form-actions">
                    <a class="btn btn-primary" href="index.html">Back to home</a>
                    <button type="button" class="btn btn-outline" id="dismissConfirmation">Close</button>
                </div>
            </div>
        </div>
    </dialog>

<?php endif; ?>
</main>

<footer class="site-footer">
    &copy; 2026 Student Technology and Innovation Conference
</footer>

<?php if (count($errors) === 0): ?>
<script src="js/modal.js"></script>
<?php endif; ?>
</body>
</html>
