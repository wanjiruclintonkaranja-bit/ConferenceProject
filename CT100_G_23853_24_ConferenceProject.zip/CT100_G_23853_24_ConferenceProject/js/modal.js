/* ==========================================================
   modal.js
   Opens the registration confirmation as a modal on process.php
   ========================================================== */

const confirmationModal = document.getElementById("confirmationModal");
const openButton = document.getElementById("openConfirmation");
const closeButton = document.getElementById("closeConfirmation");
const dismissButton = document.getElementById("dismissConfirmation");

// Open the confirmation as a true modal (focus is kept inside it)
function openConfirmation() {
    if (confirmationModal.open) {
        confirmationModal.close();   // reset the no-JavaScript fallback state
    }
    confirmationModal.showModal();
}

function closeConfirmation() {
    confirmationModal.close();
}

// Close when the dark area outside the modal is clicked
function closeOnBackdropClick(event) {
    if (event.target === confirmationModal) {
        closeConfirmation();
    }
}

openButton.addEventListener("click", openConfirmation);
closeButton.addEventListener("click", closeConfirmation);
dismissButton.addEventListener("click", closeConfirmation);
confirmationModal.addEventListener("click", closeOnBackdropClick);

// Show the modal as soon as the page loads (Escape also closes it)
openConfirmation();
