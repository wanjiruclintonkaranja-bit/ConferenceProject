/* ==========================================================
   Student Technology and Innovation Conference
   script.js: validation, dynamic form behaviour, fee calculator
   ========================================================== */

/* ---------- Fee settings (KSh). Change prices here. ---------- */
const FEES = {
    registration: 1000,   // once per participant
    perDay: 500,          // attendance per day
    workshop: 750,        // one workshop
    lunchPerDay: 300      // lunch per day
};

// Individual requirement (last digit 3): final-year students get 5% off
const FINAL_YEAR_DISCOUNT_PERCENT = 5;

const MIN_DAYS = 1;
const MAX_DAYS = 3;

// Same rule as process.php: letters, numbers, / - _ and spaces, 3 to 30 characters
const ADMISSION_PATTERN = /^[A-Za-z0-9\/\-_ ]{3,30}$/;

/* ---------- Element references ---------- */
const form = document.getElementById("registrationForm");
const fullNameInput = document.getElementById("fullName");
const admissionInput = document.getElementById("admissionNumber");
const emailInput = document.getElementById("email");
const phoneInput = document.getElementById("phone");
const yearSelect = document.getElementById("yearOfStudy");
const categorySelect = document.getElementById("category");
const daysInput = document.getElementById("days");
const workshopSection = document.getElementById("workshopSection");
const workshopSelect = document.getElementById("workshop");
const cateringCheckbox = document.getElementById("catering");
const mealSection = document.getElementById("mealSection");
const mealSelect = document.getElementById("mealOption");
const packageMessage = document.getElementById("packageMessage");
const feeBreakdown = document.getElementById("feeBreakdown");
const totalFeeText = document.getElementById("totalFee");
const totalHidden = document.getElementById("totalFromJs");
const resetButton = document.getElementById("resetButton");

/* ---------- Helpers ---------- */

// Format a number as "KSh 3,350"
function formatKsh(amount) {
    return "KSh " + amount.toLocaleString("en-US");
}

// Number of days as an integer, or 0 when the entry is not valid
function getValidDays() {
    const days = Number(daysInput.value);
    if (Number.isInteger(days) && days >= MIN_DAYS && days <= MAX_DAYS) {
        return days;
    }
    return 0;
}

function showError(input, errorId, message) {
    document.getElementById(errorId).textContent = message;
    if (input) {
        input.classList.add("invalid");
    }
}

function clearErrors() {
    document.querySelectorAll(".error").forEach(function (el) {
        el.textContent = "";
    });
    document.querySelectorAll(".invalid").forEach(function (el) {
        el.classList.remove("invalid");
    });
}

/* ==========================================================
   Dynamic behaviour (Task 3)
   ========================================================== */

// Show workshop options for Workshop Participant, hide for Conference Only
function showWorkshop() {
    const isWorkshop = categorySelect.value === "workshop";

    workshopSection.hidden = !isWorkshop;
    workshopSelect.disabled = !isWorkshop;

    // Clear the choice when the options are hidden
    if (!isWorkshop) {
        workshopSelect.value = "";
    }
}

// Show meal options only when catering is selected
function showMeals() {
    const wantsCatering = cateringCheckbox.checked;

    mealSection.hidden = !wantsCatering;
    mealSelect.disabled = !wantsCatering;
}

// Display a message describing the selected package
function showPackage() {
    const days = getValidDays();

    if (categorySelect.value === "") {
        packageMessage.textContent = "Select a category to see your package.";
        return;
    }

    const parts = [];
    parts.push(categorySelect.value === "workshop" ? "Workshop Participant" : "Conference Only");
    parts.push(days > 0 ? days + (days === 1 ? " day" : " days") : "days not set");

    if (workshopSelect.value !== "") {
        parts.push("workshop: " + workshopSelect.options[workshopSelect.selectedIndex].text);
    }
    if (cateringCheckbox.checked) { parts.push("lunch included"); }
    if (yearSelect.value === "final") { parts.push("final-year discount applied"); }

    packageMessage.textContent = "Your package: " + parts.join(", ") + ".";
}

/* ==========================================================
   Fee calculator (Task 4)
   Total = Registration + Attendance + Workshop + Meals - Discount
   ========================================================== */
function calculateFee() {
    const days = getValidDays();
    const rows = [];
    let subtotal = 0;

    // Registration fee
    subtotal += FEES.registration;
    rows.push(["Registration", FEES.registration]);

    // Attendance fee
    const attendanceFee = days * FEES.perDay;
    subtotal += attendanceFee;
    rows.push(["Attendance (" + days + " x " + FEES.perDay.toLocaleString("en-US") + ")", attendanceFee]);

    // Workshop fee (only counted for Workshop Participant who chose a workshop)
    if (categorySelect.value === "workshop" && workshopSelect.value !== "") {
        subtotal += FEES.workshop;
        rows.push(["Workshop", FEES.workshop]);
    }

    // Meal fee
    if (cateringCheckbox.checked) {
        const mealFee = days * FEES.lunchPerDay;
        subtotal += mealFee;
        rows.push(["Lunch (" + days + " x " + FEES.lunchPerDay + ")", mealFee]);
    }

    // Final-year discount: 5% of the subtotal, rounded to the nearest shilling
    let discount = 0;
    if (yearSelect.value === "final") {
        discount = Math.round(subtotal * FINAL_YEAR_DISCOUNT_PERCENT / 100);
    }

    const total = subtotal - discount;

    // Draw the breakdown
    feeBreakdown.innerHTML = "";
    rows.forEach(function (row) {
        addBreakdownRow(row[0], formatKsh(row[1]), false);
    });
    if (discount > 0) {
        addBreakdownRow("Final-year discount (" + FINAL_YEAR_DISCOUNT_PERCENT + "%)", "- " + formatKsh(discount), true);
    }

    totalFeeText.textContent = formatKsh(total);
    totalHidden.value = total;   // sent to PHP, which re-checks it
    return total;
}

// Add one line to the fee summary list
function addBreakdownRow(labelText, amountText, isDiscount) {
    const item = document.createElement("li");
    const label = document.createElement("span");
    const amount = document.createElement("span");
    label.textContent = labelText;
    amount.textContent = amountText;
    if (isDiscount) {
        item.className = "discount";
    }
    item.appendChild(label);
    item.appendChild(amount);
    feeBreakdown.appendChild(item);
}

// Refresh everything that depends on the selections
function updateForm() {
    showWorkshop();
    showMeals();
    showPackage();
    calculateFee();
}

/* ==========================================================
   Validation (Task 2)
   ========================================================== */
function validateForm(event) {
    clearErrors();
    let firstInvalid = null;

    function fail(input, errorId, message) {
        showError(input, errorId, message);
        if (!firstInvalid) { firstInvalid = input; }
    }

    // 1. Full name cannot be empty
    if (fullNameInput.value.trim() === "") {
        fail(fullNameInput, "error-fullName", "Enter your full name.");
    }

    // Admission number: required, and same format rule as the server
    if (admissionInput.value.trim() === "") {
        fail(admissionInput, "error-admissionNumber", "Enter your admission or registration number.");
    } else if (!ADMISSION_PATTERN.test(admissionInput.value.trim())) {
        fail(admissionInput, "error-admissionNumber", "Use 3 to 30 letters, numbers, / - _ or spaces, for example CT100/G/23853/24.");
    }

    // 2. Email must have a valid format
    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailPattern.test(emailInput.value.trim())) {
        fail(emailInput, "error-email", "Enter a valid email address, for example mary@example.com.");
    }

    // 3. Phone must contain exactly 10 digits
    if (!/^\d{10}$/.test(phoneInput.value.trim())) {
        fail(phoneInput, "error-phone", "Phone number must be exactly 10 digits.");
    }

    // Year of study is required (needed for the final-year discount)
    if (yearSelect.value === "") {
        fail(yearSelect, "error-yearOfStudy", "Select your year of study.");
    }

    // 5. A participation category must be selected
    if (categorySelect.value === "") {
        fail(categorySelect, "error-category", "Select a participation category.");
    }

    // 4. Days must be between 1 and 3
    if (getValidDays() === 0) {
        fail(daysInput, "error-days", "Number of days must be a whole number from " + MIN_DAYS + " to " + MAX_DAYS + ".");
    }

    // Workshop participants must choose a workshop
    if (categorySelect.value === "workshop" && workshopSelect.value === "") {
        fail(workshopSelect, "error-workshop", "Select a workshop, or choose Conference Only.");
    }

    // Block submission when anything is invalid
    if (firstInvalid) {
        event.preventDefault();
        firstInvalid.focus();
        return false;
    }

    calculateFee();   // make sure the hidden total is current
    return true;
}

// Clear the form and reset the dynamic parts
function resetForm() {
    form.reset();
    clearErrors();
    updateForm();
}

/* ==========================================================
   Events (Task 5)
   ========================================================== */
form.addEventListener("submit", validateForm);               // submit
categorySelect.addEventListener("change", updateForm);       // change
cateringCheckbox.addEventListener("change", updateForm);     // change
workshopSelect.addEventListener("change", updateForm);       // change
yearSelect.addEventListener("change", updateForm);           // change
daysInput.addEventListener("input", updateForm);             // input
resetButton.addEventListener("click", resetForm);            // click

// Set the initial state when the page loads
updateForm();
